package com.example.demo.model;                 //tried to do like user,but failed refer project Train_Ticket

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="trains")
public class Train {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int id;
	@Column(name="train_no")
	private int train_no;
	@Column(name="train_name")
	private String train_name;
	@Column(name="source")
	private String source;
	@Column(name="destination")
	private String destination;
	@Column(name="price")
	private int price;
	
	Train(){
		
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getTrain_no() {
		return train_no;
	}

	public void setTrain_no(int train_no) {
		this.train_no = train_no;
	}

	public String getTrain_name() {
		return train_name;
	}

	public void setTrain_name(String train_name) {
		this.train_name = train_name;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public String getDestination() {
		return destination;
	}

	public void setDestination(String destination) {
		this.destination = destination;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public Train(int train_no, String train_name, String source, String destination, int price) {
		super();
		this.train_no = train_no;
		this.train_name = train_name;
		this.source = source;
		this.destination = destination;
		this.price = price;
	}
	
	public String toString() {
		return "Train [id= " +id+ ",train number=  " +train_no+ ",train name= " +train_name+ ",source= " +source+ ",destination= "+destination+ ",price= "+price+ "]";
	}
	
	

}

