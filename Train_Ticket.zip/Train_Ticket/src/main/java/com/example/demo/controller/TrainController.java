package com.example.demo.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.Train;

import com.example.demo.repository.TrainRepository;

@CrossOrigin(origins="*")
@RestController
@RequestMapping("/api")
public class TrainController {
	@Autowired
	TrainRepository trainRepository;
	@PostMapping("/inserttrain")
	public ResponseEntity<Train> createTrain(@RequestBody Train train)
	{
		
		try
		{
	   	   Train	_train= trainRepository.save(new Train(train.getTrain_name(),train.getSource(),train.getDestination(),train.getPrice()));
	       return new ResponseEntity<>(_train,HttpStatus.CREATED);
		}
		catch(Exception e)
		{
			return new ResponseEntity<>(null,HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@GetMapping("/alltrains")
	public ResponseEntity<List<Train>> getAllTrains()
	{
		
		try
		{
	   	   List<Train> train_=new ArrayList<Train>();
	   	   trainRepository.findAll().forEach(train_::add);
	       return new ResponseEntity<>(train_,HttpStatus.OK);
		}
		catch(Exception e)
		{
			return new ResponseEntity<>(null,HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	@GetMapping("/gettrain/{Train_no}")
	public ResponseEntity<Train> getTrainById(@PathVariable("Train_no") int Train_no)
	{
		
		
			Optional<Train> trainData=trainRepository.findById(Train_no);
			if(trainData.isPresent()) {
				 return new ResponseEntity<>(trainData.get(), HttpStatus.OK);
			}
	      
			else
			{
				return new ResponseEntity<>(null,HttpStatus.NOT_FOUND);
			}
	}
		
	
	@PutMapping("/updatetrain/{Train_no}")
	public ResponseEntity<Train> updateTrain(@PathVariable("Train_no") int Train_no,@RequestBody Train train)
	{
		
		
			Optional<Train> trainData=trainRepository.findById(Train_no);
			if(trainData.isPresent()) {
				Train train__=trainData.get();
				train__.setTrain_name(train.getTrain_name());
				train__.setSource(train.getSource());
				train__.setDestination(train.getDestination());
				train__.setPrice(train.getPrice());
				 return new ResponseEntity<>(trainRepository.save(train__), HttpStatus.OK);
			}
	      
			else
			{
				return new ResponseEntity<>(null,HttpStatus.NOT_FOUND);
			}
		
			
	} 
	
	@DeleteMapping("/deleteTrain/{Train_no}")
	public ResponseEntity<HttpStatus> deleteTrain(@PathVariable("Train_no") int id){
		
		try
		{
			trainRepository.deleteById(id);
		return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		}
		catch(Exception ex)
		{
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	
	}
    

}
