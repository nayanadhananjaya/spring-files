package com.example.train.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


import com.example.train.model.Train;
import com.example.train.repository.TrainRepository;

@CrossOrigin(origins="http://localhost:8080/api/train")
@RestController
@RequestMapping("/api")

public class TrainController {
	@Autowired
	TrainRepository trainRepository;
	
	@PostMapping("/train")
    public ResponseEntity<Train> createUser(@RequestBody Train train){
		try {
			Train _train =trainRepository.save(new Train(train.getTrain_no(),train.getTrain_name(),train.getSource(),train.getDestination(),train.getPrice()));
      	    return new ResponseEntity<>(_train,HttpStatus.CREATED);
		}catch(Exception ex){
			return new ResponseEntity<>(null,HttpStatus.INTERNAL_SERVER_ERROR);
		}
    }
	
	@GetMapping("/train")
	public ResponseEntity<List<Train>>getAllUsers(){
		try {
			List<Train> train= new ArrayList<Train>();
			trainRepository.findAll().forEach(train::add);
			return new ResponseEntity<>(train,HttpStatus.OK);
		}catch(Exception ex) {
			return new ResponseEntity<>(null,HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@GetMapping("/train/{id}")
	public ResponseEntity<Train>getUserById(@PathVariable("id")int id){
		Optional<Train> userData = trainRepository.findById(id);
		if(userData.isPresent()) {
			return new ResponseEntity<>(userData.get(),HttpStatus.OK);
		}else {
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}
	}
	
	@PutMapping("/train/{id}")
	public ResponseEntity<Train> updateUser(@PathVariable("id")int id,@RequestBody Train train){
		Optional<Train> trainData = trainRepository.findById(id);
		if(trainData.isPresent()) {
			Train _train=trainData.get();
			_train.setTrain_no(train.getTrain_no());
			_train.setTrain_name(train.getTrain_name());
			_train.setSource(train.getSource());
			_train.setDestination(train.getDestination());
			_train.setPrice(train.getPrice());
			return new ResponseEntity<>(trainRepository.save(_train),HttpStatus.OK);
		}else {
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}

    }
	@DeleteMapping("/train/{id}")
	public ResponseEntity<HttpStatus>deleteUser(@PathVariable("id")int id){
		try {
			trainRepository.deleteById(id);
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		}catch(Exception ex) {
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
}	
